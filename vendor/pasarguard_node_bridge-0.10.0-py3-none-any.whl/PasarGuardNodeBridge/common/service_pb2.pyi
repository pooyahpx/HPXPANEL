from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class BackendType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    XRAY: _ClassVar[BackendType]
    WIREGUARD: _ClassVar[BackendType]
    OPENVPN: _ClassVar[BackendType]
    IKEV2: _ClassVar[BackendType]
    L2TP: _ClassVar[BackendType]
    PPTP: _ClassVar[BackendType]
    OPENCONNECT: _ClassVar[BackendType]
    SSTP: _ClassVar[BackendType]
    WG_C: _ClassVar[BackendType]
    AMNEZIAWG: _ClassVar[BackendType]
    GRE: _ClassVar[BackendType]
    SSH: _ClassVar[BackendType]
    MTPROTO: _ClassVar[BackendType]

class StatType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    Outbounds: _ClassVar[StatType]
    Outbound: _ClassVar[StatType]
    Inbounds: _ClassVar[StatType]
    Inbound: _ClassVar[StatType]
    UsersStat: _ClassVar[StatType]
    UserStat: _ClassVar[StatType]
XRAY: BackendType
WIREGUARD: BackendType
OPENVPN: BackendType
IKEV2: BackendType
L2TP: BackendType
PPTP: BackendType
OPENCONNECT: BackendType
SSTP: BackendType
WG_C: BackendType
AMNEZIAWG: BackendType
GRE: BackendType
SSH: BackendType
MTPROTO: BackendType
Outbounds: StatType
Outbound: StatType
Inbounds: StatType
Inbound: StatType
UsersStat: StatType
UserStat: StatType

class Empty(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class BaseInfoResponse(_message.Message):
    __slots__ = ("started", "core_version", "node_version", "available_backends", "backend_versions")
    class BackendVersionsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    STARTED_FIELD_NUMBER: _ClassVar[int]
    CORE_VERSION_FIELD_NUMBER: _ClassVar[int]
    NODE_VERSION_FIELD_NUMBER: _ClassVar[int]
    AVAILABLE_BACKENDS_FIELD_NUMBER: _ClassVar[int]
    BACKEND_VERSIONS_FIELD_NUMBER: _ClassVar[int]
    started: bool
    core_version: str
    node_version: str
    available_backends: _containers.RepeatedScalarFieldContainer[BackendType]
    backend_versions: _containers.ScalarMap[str, str]
    def __init__(self, started: bool = ..., core_version: _Optional[str] = ..., node_version: _Optional[str] = ..., available_backends: _Optional[_Iterable[_Union[BackendType, str]]] = ..., backend_versions: _Optional[_Mapping[str, str]] = ...) -> None: ...

class Backend(_message.Message):
    __slots__ = ("type", "config", "users", "keep_alive", "exclude_inbounds")
    TYPE_FIELD_NUMBER: _ClassVar[int]
    CONFIG_FIELD_NUMBER: _ClassVar[int]
    USERS_FIELD_NUMBER: _ClassVar[int]
    KEEP_ALIVE_FIELD_NUMBER: _ClassVar[int]
    EXCLUDE_INBOUNDS_FIELD_NUMBER: _ClassVar[int]
    type: BackendType
    config: str
    users: _containers.RepeatedCompositeFieldContainer[User]
    keep_alive: int
    exclude_inbounds: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, type: _Optional[_Union[BackendType, str]] = ..., config: _Optional[str] = ..., users: _Optional[_Iterable[_Union[User, _Mapping]]] = ..., keep_alive: _Optional[int] = ..., exclude_inbounds: _Optional[_Iterable[str]] = ...) -> None: ...

class Log(_message.Message):
    __slots__ = ("detail",)
    DETAIL_FIELD_NUMBER: _ClassVar[int]
    detail: str
    def __init__(self, detail: _Optional[str] = ...) -> None: ...

class Stat(_message.Message):
    __slots__ = ("name", "type", "link", "value")
    NAME_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    LINK_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    name: str
    type: str
    link: str
    value: int
    def __init__(self, name: _Optional[str] = ..., type: _Optional[str] = ..., link: _Optional[str] = ..., value: _Optional[int] = ...) -> None: ...

class StatResponse(_message.Message):
    __slots__ = ("stats",)
    STATS_FIELD_NUMBER: _ClassVar[int]
    stats: _containers.RepeatedCompositeFieldContainer[Stat]
    def __init__(self, stats: _Optional[_Iterable[_Union[Stat, _Mapping]]] = ...) -> None: ...

class StatRequest(_message.Message):
    __slots__ = ("name", "reset", "type")
    NAME_FIELD_NUMBER: _ClassVar[int]
    RESET_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    name: str
    reset: bool
    type: StatType
    def __init__(self, name: _Optional[str] = ..., reset: bool = ..., type: _Optional[_Union[StatType, str]] = ...) -> None: ...

class OnlineStatResponse(_message.Message):
    __slots__ = ("name", "value")
    NAME_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    name: str
    value: int
    def __init__(self, name: _Optional[str] = ..., value: _Optional[int] = ...) -> None: ...

class StatsOnlineIpListResponse(_message.Message):
    __slots__ = ("name", "ips", "ip_protocol")
    class IpsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: int
        def __init__(self, key: _Optional[str] = ..., value: _Optional[int] = ...) -> None: ...
    class IpProtocolEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    NAME_FIELD_NUMBER: _ClassVar[int]
    IPS_FIELD_NUMBER: _ClassVar[int]
    IP_PROTOCOL_FIELD_NUMBER: _ClassVar[int]
    name: str
    ips: _containers.ScalarMap[str, int]
    ip_protocol: _containers.ScalarMap[str, str]
    def __init__(self, name: _Optional[str] = ..., ips: _Optional[_Mapping[str, int]] = ..., ip_protocol: _Optional[_Mapping[str, str]] = ...) -> None: ...

class Latency(_message.Message):
    __slots__ = ("name", "alive", "delay", "link", "last_seen_time", "last_try_time", "source")
    NAME_FIELD_NUMBER: _ClassVar[int]
    ALIVE_FIELD_NUMBER: _ClassVar[int]
    DELAY_FIELD_NUMBER: _ClassVar[int]
    LINK_FIELD_NUMBER: _ClassVar[int]
    LAST_SEEN_TIME_FIELD_NUMBER: _ClassVar[int]
    LAST_TRY_TIME_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    name: str
    alive: bool
    delay: int
    link: str
    last_seen_time: int
    last_try_time: int
    source: str
    def __init__(self, name: _Optional[str] = ..., alive: bool = ..., delay: _Optional[int] = ..., link: _Optional[str] = ..., last_seen_time: _Optional[int] = ..., last_try_time: _Optional[int] = ..., source: _Optional[str] = ...) -> None: ...

class LatencyRequest(_message.Message):
    __slots__ = ("name",)
    NAME_FIELD_NUMBER: _ClassVar[int]
    name: str
    def __init__(self, name: _Optional[str] = ...) -> None: ...

class LatencyResponse(_message.Message):
    __slots__ = ("latencies",)
    LATENCIES_FIELD_NUMBER: _ClassVar[int]
    latencies: _containers.RepeatedCompositeFieldContainer[Latency]
    def __init__(self, latencies: _Optional[_Iterable[_Union[Latency, _Mapping]]] = ...) -> None: ...

class BackendStatsResponse(_message.Message):
    __slots__ = ("num_goroutine", "num_gc", "alloc", "total_alloc", "sys", "mallocs", "frees", "live_objects", "pause_total_ns", "uptime")
    NUM_GOROUTINE_FIELD_NUMBER: _ClassVar[int]
    NUM_GC_FIELD_NUMBER: _ClassVar[int]
    ALLOC_FIELD_NUMBER: _ClassVar[int]
    TOTAL_ALLOC_FIELD_NUMBER: _ClassVar[int]
    SYS_FIELD_NUMBER: _ClassVar[int]
    MALLOCS_FIELD_NUMBER: _ClassVar[int]
    FREES_FIELD_NUMBER: _ClassVar[int]
    LIVE_OBJECTS_FIELD_NUMBER: _ClassVar[int]
    PAUSE_TOTAL_NS_FIELD_NUMBER: _ClassVar[int]
    UPTIME_FIELD_NUMBER: _ClassVar[int]
    num_goroutine: int
    num_gc: int
    alloc: int
    total_alloc: int
    sys: int
    mallocs: int
    frees: int
    live_objects: int
    pause_total_ns: int
    uptime: int
    def __init__(self, num_goroutine: _Optional[int] = ..., num_gc: _Optional[int] = ..., alloc: _Optional[int] = ..., total_alloc: _Optional[int] = ..., sys: _Optional[int] = ..., mallocs: _Optional[int] = ..., frees: _Optional[int] = ..., live_objects: _Optional[int] = ..., pause_total_ns: _Optional[int] = ..., uptime: _Optional[int] = ...) -> None: ...

class SystemStatsResponse(_message.Message):
    __slots__ = ("mem_total", "mem_used", "cpu_cores", "cpu_usage", "incoming_bandwidth_speed", "outgoing_bandwidth_speed", "uptime")
    MEM_TOTAL_FIELD_NUMBER: _ClassVar[int]
    MEM_USED_FIELD_NUMBER: _ClassVar[int]
    CPU_CORES_FIELD_NUMBER: _ClassVar[int]
    CPU_USAGE_FIELD_NUMBER: _ClassVar[int]
    INCOMING_BANDWIDTH_SPEED_FIELD_NUMBER: _ClassVar[int]
    OUTGOING_BANDWIDTH_SPEED_FIELD_NUMBER: _ClassVar[int]
    UPTIME_FIELD_NUMBER: _ClassVar[int]
    mem_total: int
    mem_used: int
    cpu_cores: int
    cpu_usage: float
    incoming_bandwidth_speed: int
    outgoing_bandwidth_speed: int
    uptime: int
    def __init__(self, mem_total: _Optional[int] = ..., mem_used: _Optional[int] = ..., cpu_cores: _Optional[int] = ..., cpu_usage: _Optional[float] = ..., incoming_bandwidth_speed: _Optional[int] = ..., outgoing_bandwidth_speed: _Optional[int] = ..., uptime: _Optional[int] = ...) -> None: ...

class Vmess(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class Vless(_message.Message):
    __slots__ = ("id", "flow")
    ID_FIELD_NUMBER: _ClassVar[int]
    FLOW_FIELD_NUMBER: _ClassVar[int]
    id: str
    flow: str
    def __init__(self, id: _Optional[str] = ..., flow: _Optional[str] = ...) -> None: ...

class Trojan(_message.Message):
    __slots__ = ("password",)
    PASSWORD_FIELD_NUMBER: _ClassVar[int]
    password: str
    def __init__(self, password: _Optional[str] = ...) -> None: ...

class Shadowsocks(_message.Message):
    __slots__ = ("password", "method")
    PASSWORD_FIELD_NUMBER: _ClassVar[int]
    METHOD_FIELD_NUMBER: _ClassVar[int]
    password: str
    method: str
    def __init__(self, password: _Optional[str] = ..., method: _Optional[str] = ...) -> None: ...

class Wireguard(_message.Message):
    __slots__ = ("public_key", "peer_ips")
    PUBLIC_KEY_FIELD_NUMBER: _ClassVar[int]
    PEER_IPS_FIELD_NUMBER: _ClassVar[int]
    public_key: str
    peer_ips: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, public_key: _Optional[str] = ..., peer_ips: _Optional[_Iterable[str]] = ...) -> None: ...

class Hysteria(_message.Message):
    __slots__ = ("auth",)
    AUTH_FIELD_NUMBER: _ClassVar[int]
    auth: str
    def __init__(self, auth: _Optional[str] = ...) -> None: ...

class Openvpn(_message.Message):
    __slots__ = ("serial", "fingerprint")
    SERIAL_FIELD_NUMBER: _ClassVar[int]
    FINGERPRINT_FIELD_NUMBER: _ClassVar[int]
    serial: str
    fingerprint: str
    def __init__(self, serial: _Optional[str] = ..., fingerprint: _Optional[str] = ...) -> None: ...

class Ikev2(_message.Message):
    __slots__ = ("username", "password")
    USERNAME_FIELD_NUMBER: _ClassVar[int]
    PASSWORD_FIELD_NUMBER: _ClassVar[int]
    username: str
    password: str
    def __init__(self, username: _Optional[str] = ..., password: _Optional[str] = ...) -> None: ...

class Credential(_message.Message):
    __slots__ = ("username", "password")
    USERNAME_FIELD_NUMBER: _ClassVar[int]
    PASSWORD_FIELD_NUMBER: _ClassVar[int]
    username: str
    password: str
    def __init__(self, username: _Optional[str] = ..., password: _Optional[str] = ...) -> None: ...

class Gre(_message.Message):
    __slots__ = ("peer_ip",)
    PEER_IP_FIELD_NUMBER: _ClassVar[int]
    peer_ip: str
    def __init__(self, peer_ip: _Optional[str] = ...) -> None: ...

class Mtproto(_message.Message):
    __slots__ = ("secret",)
    SECRET_FIELD_NUMBER: _ClassVar[int]
    secret: str
    def __init__(self, secret: _Optional[str] = ...) -> None: ...

class AnyTLS(_message.Message):
    __slots__ = ("password",)
    PASSWORD_FIELD_NUMBER: _ClassVar[int]
    password: str
    def __init__(self, password: _Optional[str] = ...) -> None: ...

class Tuic(_message.Message):
    __slots__ = ("id", "password")
    ID_FIELD_NUMBER: _ClassVar[int]
    PASSWORD_FIELD_NUMBER: _ClassVar[int]
    id: str
    password: str
    def __init__(self, id: _Optional[str] = ..., password: _Optional[str] = ...) -> None: ...

class Naive(_message.Message):
    __slots__ = ("username", "password")
    USERNAME_FIELD_NUMBER: _ClassVar[int]
    PASSWORD_FIELD_NUMBER: _ClassVar[int]
    username: str
    password: str
    def __init__(self, username: _Optional[str] = ..., password: _Optional[str] = ...) -> None: ...

class Proxy(_message.Message):
    __slots__ = ("vmess", "vless", "trojan", "shadowsocks", "wireguard", "hysteria", "openvpn", "ikev2", "pptp", "openconnect", "sstp", "ssh", "wg_c", "amneziawg", "gre", "mtproto", "anytls", "tuic", "naive")
    VMESS_FIELD_NUMBER: _ClassVar[int]
    VLESS_FIELD_NUMBER: _ClassVar[int]
    TROJAN_FIELD_NUMBER: _ClassVar[int]
    SHADOWSOCKS_FIELD_NUMBER: _ClassVar[int]
    WIREGUARD_FIELD_NUMBER: _ClassVar[int]
    HYSTERIA_FIELD_NUMBER: _ClassVar[int]
    OPENVPN_FIELD_NUMBER: _ClassVar[int]
    IKEV2_FIELD_NUMBER: _ClassVar[int]
    PPTP_FIELD_NUMBER: _ClassVar[int]
    OPENCONNECT_FIELD_NUMBER: _ClassVar[int]
    SSTP_FIELD_NUMBER: _ClassVar[int]
    SSH_FIELD_NUMBER: _ClassVar[int]
    WG_C_FIELD_NUMBER: _ClassVar[int]
    AMNEZIAWG_FIELD_NUMBER: _ClassVar[int]
    GRE_FIELD_NUMBER: _ClassVar[int]
    MTPROTO_FIELD_NUMBER: _ClassVar[int]
    ANYTLS_FIELD_NUMBER: _ClassVar[int]
    TUIC_FIELD_NUMBER: _ClassVar[int]
    NAIVE_FIELD_NUMBER: _ClassVar[int]
    vmess: Vmess
    vless: Vless
    trojan: Trojan
    shadowsocks: Shadowsocks
    wireguard: Wireguard
    hysteria: Hysteria
    openvpn: Openvpn
    ikev2: Ikev2
    pptp: Credential
    openconnect: Credential
    sstp: Credential
    ssh: Credential
    wg_c: Wireguard
    amneziawg: Wireguard
    gre: Gre
    mtproto: Mtproto
    anytls: AnyTLS
    tuic: Tuic
    naive: Naive
    def __init__(self, vmess: _Optional[_Union[Vmess, _Mapping]] = ..., vless: _Optional[_Union[Vless, _Mapping]] = ..., trojan: _Optional[_Union[Trojan, _Mapping]] = ..., shadowsocks: _Optional[_Union[Shadowsocks, _Mapping]] = ..., wireguard: _Optional[_Union[Wireguard, _Mapping]] = ..., hysteria: _Optional[_Union[Hysteria, _Mapping]] = ..., openvpn: _Optional[_Union[Openvpn, _Mapping]] = ..., ikev2: _Optional[_Union[Ikev2, _Mapping]] = ..., pptp: _Optional[_Union[Credential, _Mapping]] = ..., openconnect: _Optional[_Union[Credential, _Mapping]] = ..., sstp: _Optional[_Union[Credential, _Mapping]] = ..., ssh: _Optional[_Union[Credential, _Mapping]] = ..., wg_c: _Optional[_Union[Wireguard, _Mapping]] = ..., amneziawg: _Optional[_Union[Wireguard, _Mapping]] = ..., gre: _Optional[_Union[Gre, _Mapping]] = ..., mtproto: _Optional[_Union[Mtproto, _Mapping]] = ..., anytls: _Optional[_Union[AnyTLS, _Mapping]] = ..., tuic: _Optional[_Union[Tuic, _Mapping]] = ..., naive: _Optional[_Union[Naive, _Mapping]] = ...) -> None: ...

class User(_message.Message):
    __slots__ = ("email", "proxies", "inbounds", "ip_limit", "speed_limit")
    EMAIL_FIELD_NUMBER: _ClassVar[int]
    PROXIES_FIELD_NUMBER: _ClassVar[int]
    INBOUNDS_FIELD_NUMBER: _ClassVar[int]
    IP_LIMIT_FIELD_NUMBER: _ClassVar[int]
    SPEED_LIMIT_FIELD_NUMBER: _ClassVar[int]
    email: str
    proxies: Proxy
    inbounds: _containers.RepeatedScalarFieldContainer[str]
    ip_limit: int
    speed_limit: int
    def __init__(self, email: _Optional[str] = ..., proxies: _Optional[_Union[Proxy, _Mapping]] = ..., inbounds: _Optional[_Iterable[str]] = ..., ip_limit: _Optional[int] = ..., speed_limit: _Optional[int] = ...) -> None: ...

class Users(_message.Message):
    __slots__ = ("users",)
    USERS_FIELD_NUMBER: _ClassVar[int]
    users: _containers.RepeatedCompositeFieldContainer[User]
    def __init__(self, users: _Optional[_Iterable[_Union[User, _Mapping]]] = ...) -> None: ...

class UsersChunk(_message.Message):
    __slots__ = ("users", "index", "last")
    USERS_FIELD_NUMBER: _ClassVar[int]
    INDEX_FIELD_NUMBER: _ClassVar[int]
    LAST_FIELD_NUMBER: _ClassVar[int]
    users: _containers.RepeatedCompositeFieldContainer[User]
    index: int
    last: bool
    def __init__(self, users: _Optional[_Iterable[_Union[User, _Mapping]]] = ..., index: _Optional[int] = ..., last: bool = ...) -> None: ...
